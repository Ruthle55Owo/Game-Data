class No_API_key(Exception):
    pass