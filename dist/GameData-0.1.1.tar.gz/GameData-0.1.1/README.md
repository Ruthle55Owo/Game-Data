# Get available game data from games you love to play
- Games done:
    - Brawl Stars